require 'spec_helper'
describe 'sat6productattach' do

  context 'with defaults for all parameters' do
    it { should contain_class('sat6productattach') }
  end
end
